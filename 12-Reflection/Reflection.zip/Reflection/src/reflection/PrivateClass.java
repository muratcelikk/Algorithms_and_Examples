package reflection;

public class PrivateClass {

    private static String sehir = "Golköy";

    public static String sehirAl() {
        return sehir;
    }
}
