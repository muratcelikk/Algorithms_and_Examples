package reflection;

import java.lang.reflect.Field;

public class Reflection {

    public static void main(String[] args) {

        Reflection rc = new Reflection();
        try {
            Class sınıf = Class.forName("reflection.PrivateClass");
            Field[] fields = sınıf.getDeclaredFields();
            fields[0].setAccessible(true);
            System.out.println(PrivateClass.sehirAl()); //Golköy yazdırır.(Normalde private alana erişimeyiz)//komut satırı yazarak ezersinde
            fields[0].set(null,"Gaziantep");
             System.out.println(PrivateClass.sehirAl());
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }

}
