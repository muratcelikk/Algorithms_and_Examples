package anagram;

import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author murat
 */
public class Anagram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String s1 = JOptionPane.showInputDialog("İlk kelimeyi girin"); //ilk kelimeyi alalım
        String s2 = JOptionPane.showInputDialog("İkinci kelimeyi girin"); //ikinci kelimeyi alalım

        boolean al = AnagramKontrol(s1, s2); // AnagramKontrol metoduna 2 adet karşılaştırılacak kelime gönderiyoruz, gelen sonucu 0 veya 1 olarak "al " değişkenimize alıyoruz.
        if (al) { // Eğer "al" değikeninde 1 varsa 
            JOptionPane.showMessageDialog(null, "Anagramdır");
        } else // "al" değişkeni 0 ise
        {
            JOptionPane.showMessageDialog(null, "Anagram Değildir");
        }
    }

    public static boolean AnagramKontrol(String kelime1, String kelime2) {
        char[] kelimeDizi1 = kelime1.toCharArray();//kelimeyi harflere ayırır
        char[] kelimeDizi2 = kelime2.toCharArray();//
        Arrays.sort(kelimeDizi1);//harfleri dizi şeklinde sıralar
        Arrays.sort(kelimeDizi2);//
        return Arrays.equals(kelimeDizi1, kelimeDizi2); //eşit ise 1 değil ise 0 döndür

    }
}
